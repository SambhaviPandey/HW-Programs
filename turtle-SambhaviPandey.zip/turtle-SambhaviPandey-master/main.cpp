/**
 * Main.cpp
 * Assignment 1: CSS 343
 *
 * A generic main file.
 *
 * @author Yusuf Pisan
 * @date 24 Sep 2019
 * Last modified by Sambhavi Pandey on 6 Oct 2019
 */

#include <iostream>

 //forward declaration, testAll is defined in another file
void testAll();

int main() {
	//Executes tests 
	testAll();

	std::cout << "Done!" << std::endl;
	return 0;
}